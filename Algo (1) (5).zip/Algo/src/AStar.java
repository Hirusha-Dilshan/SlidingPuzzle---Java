import java.io.*;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class AStar {
    public static String[][] arr;
    public static int si;
    public static int sj;
    public static int ei;
    public static int ej;
    public static int [][] blockList;

    public static final int DIAGONAL_COST = 14;
    public static final int V_H_COST = 10;
    //    Cell of our grid
    private Node[][] grid;

    private PriorityQueue<Node> nodes;
    private boolean[][] opened;
    private int startI, startJ;
    private int endI, endJ;

    public AStar(int width, int height, int si, int sj, int ei, int ej, int[][] blocks) {
        grid = new Node[width][height];
        opened = new boolean[width][height];
        nodes = new PriorityQueue<>((Node c1, Node c2) -> {
            return c1.finalCost < c2.finalCost ? -1 : c1.finalCost > c2.finalCost ? 1 : 0;
        });
        startI=si;
        startJ=sj;
        endJ=ej;
        endI=ei;

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                grid[i][j] = new Node(i, j);
                grid[i][j].heuristicCost = Math.abs(i - endI) + Math.abs(j - endJ);
                grid[i][j].solution = false;
            }
        }

        grid[startI][startJ].finalCost = 0;

        for (int i = 0; i < blocks.length; i++) {
            addBlockOnCell(blocks[i][0], blocks[i][1]);
        }
    }

    public void addBlockOnCell(int i, int j) {
        grid[i][j] = null;
    }


    public void updateCostIfNeeded(Node current, Node t, int cost) {
        if (t == null || opened[t.i][t.j])
            return;

        int tFinalCost = t.heuristicCost + cost;
        boolean isOpen = nodes.contains(t);

        if (!isOpen || tFinalCost < t.finalCost) {
            t.finalCost = tFinalCost;
            t.parent = current;

            if (!isOpen) {
                nodes.add(t);
            }
        }
    }

    public void process() {
        nodes.add(grid[startI][startJ]);
        Node current;

        while (true) {
            current = nodes.poll();

            if (current == null) {
                break;
            }

            opened[current.i][current.j] = true;

            if (current.equals(grid[endI][endJ])) {
                return;
            }

            Node t;

            if (current.i - 1 >= 0) {
                t = grid[current.i - 1][current.j];
                updateCostIfNeeded(current, t, current.finalCost + V_H_COST);

                if (current.j - 1 >= 0) {
                    t = grid[current.i - 1][current.j - 1];
                    updateCostIfNeeded(current, t, current.finalCost + DIAGONAL_COST);
                }

                if (current.j + 1 < grid[0].length) {
                    t = grid[current.i - 1][current.j + 1];
                    updateCostIfNeeded(current, t, current.finalCost + DIAGONAL_COST);
                }
            }

            if (current.j - 1 >= 0) {
                t = grid[current.i][current.j - 1];
                updateCostIfNeeded(current, t, current.finalCost + V_H_COST);
            }

            if (current.j + 1 < grid[0].length) {
                t = grid[current.i][current.j + 1];
                updateCostIfNeeded(current, t, current.finalCost + V_H_COST);
            }

            if (current.i + 1 < grid.length) {
                t = grid[current.i + 1][current.j];
                updateCostIfNeeded(current, t, current.finalCost + V_H_COST);

                if (current.j - 1 >= 0) {
                    t = grid[current.i + 1][current.j - 1];
                    updateCostIfNeeded(current, t, current.finalCost + DIAGONAL_COST);
                }

                if (current.j + 1 < grid[0].length) {
                    t = grid[current.i + 1][current.j + 1];
                    updateCostIfNeeded(current, t, current.finalCost + DIAGONAL_COST);
                }
            }
        }
    }


    public void displaySolution() {
        ArrayList<Node> nodesIn = new ArrayList<>();//cells in right order
        if (opened[endI][endJ]) {
            System.out.println("Path :");
            Node current = grid[endI][endJ];
            System.out.println(current);
            grid[current.i][current.j].solution = true;

            while (current.parent != null) {
                nodesIn.add(0,current.parent);
                grid[current.parent.i][current.parent.j].solution = true;
                current = current.parent;
            }
            Node temp=null;
            for (Node cell:nodesIn) {
                if(temp == null) {//first node
                    System.out.println("Start at ("+(cell.j+1)+","+(cell.i+1)+")");//change i and j while printing to more visualisation
                }else{
                    if(temp.i>cell.i){
                        System.out.println("Move up to ("+(cell.j+1)+","+(cell.i+1)+")");
                    }else if(temp.i<cell.i){
                        System.out.println("Move down to  ("+(cell.j+1)+","+(cell.i+1)+")");
                    }else if(temp.j>cell.j){
                        System.out.println("Move left to  ("+(cell.j+1)+","+(cell.i+1)+")");
                    }else if(temp.j<cell.j){
                        System.out.println("Move right to ("+(cell.j+1)+","+(cell.i+1)+")");
                    }
                }
                temp=cell;

            }
            System.out.println("Done!");

        } else {
            System.out.println("No possible path");
        }
    }

    public static void main(String[] args) throws IOException {
        File file=new File("maze30_5.txt");
        Scanner input= null;
        try {
            input = new Scanner(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        arr=new String[numOfRows()][numOfColumns()];

        int index=0;
        while(input.hasNextLine()){
            arr[index]=input.nextLine().split("(?!^)");
            index++;
        }
        printArr();

        startAndEnd();
        blocks();

        AStar aStar = new AStar(numOfColumns(),numOfRows(), si, sj, ei, ej,
                blockList);
        long startTime = System.nanoTime();
        aStar.process();
        long endTime = System.nanoTime();

        aStar.displaySolution();

        long duration = (endTime - startTime);
        System.out.println("Elapsed time = " + (double)duration/1000000 +" milliseconds");;
    }
    public static int numOfRows() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("maze30_5.txt"));
        int lines = 0;
        while (reader.readLine() != null) lines++;
        reader.close();
        return lines;
    }
    public static int numOfColumns() throws FileNotFoundException {
        int numOfColumns = 0;
        File file=new File("maze30_5.txt");
        Scanner input=new Scanner(file);
        numOfColumns=input.nextLine().split("(?!^)").length;
        return numOfColumns;
    }
    public static void startAndEnd(){
        for (int i=0;i<arr.length; i++) {
            for (int j=0;j<arr[i].length;j++) {
                if(arr[i][j].equals("S")){
                    si=i;
                    sj=j;
                }else if(arr[i][j].equals("F")){
                    ei=i;
                    ej=j;
                }
            }
        }
    }
    public static void printArr(){
        for (String [] row:arr) {
            for (String column:row) {
                System.out.print(column);
            }
            System.out.println();
        }
    }
    public static void blocks(){
        ArrayList<int[]> blocks = new ArrayList<int[]>();
        for (int i=0;i<arr.length; i++) {
            for (int j=0;j<arr[i].length;j++) {
                if(arr[i][j].equals("0")){
                    blocks.add(new int[]{i,j});
                }
            }
        }

        //initialize blockList array
        blockList=new int[blocks.size()][2];
        for(int i=0;i<blocks.size();i++){
            blockList[i]=blocks.get(i);
        }
    }
}